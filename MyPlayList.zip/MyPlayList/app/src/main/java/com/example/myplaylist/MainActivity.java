package com.example.myplaylist;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<Musica> arrayList;
    ArrayAdapter<Musica> adapter;
    MediaPlayer player;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.idListView);
        arrayList = new ArrayList<>();
        arrayList.add(new Musica("LE SSERAFIM - Easy", R.raw.easy));
        arrayList.add(new Musica("Paramore - Ignorance", R.raw.ignorance));
        arrayList.add(new Musica("Ariana Grande - No Tears Left To Cry", R.raw.notearslefttocry));
        adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, arrayList);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
                Musica musicaSelecionada = arrayList.get(i);
                int audioId = musicaSelecionada.getAudioResourceId();

                //Libera os recursos do player
                if(player != null){
                    player.release();
                    player = null;
                }

                player = MediaPlayer.create(MainActivity.this, audioId);
                player.start();

            }
        });

    }
}