package com.example.myplaylist;

public class Musica {

    public String nome;
    private int audioResourceId;

    public Musica(){

    }

    public Musica(String nome, int audioResourceId){

        this.nome = nome;
        this.audioResourceId = audioResourceId;

    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getAudioResourceId() {
        return audioResourceId;
    }

    public void setAudioResourceId(int audioResourceId) {
        this.audioResourceId = audioResourceId;
    }

    @Override
    public String toString() {
        return nome+"\n";
    }
}
